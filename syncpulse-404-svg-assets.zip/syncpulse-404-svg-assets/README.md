# SyncPulse 404 SVG Assets

Generated responsive SVG assets based on the existing 404.svg source concept. Mascot is intentionally not baked into these background/page assets so it can be layered separately.
